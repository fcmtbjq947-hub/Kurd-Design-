
// Simple front-end logic: preview upload onto SVG mockups, cart management

let currentProd = 'mug';
const prodBtns = document.querySelectorAll('.prod-btn');
const previewWrapper = document.getElementById('previewWrapper');
const imgInput = document.getElementById('imgInput');
const textInput = document.getElementById('textInput');
const qtyInput = document.getElementById('qtyInput');
const addToCartBtn = document.getElementById('addToCart');
const cartList = document.getElementById('cartList');
const cartEmpty = document.getElementById('cartEmpty');
const orderForm = document.getElementById('orderForm');
const orderMsg = document.getElementById('orderMsg');
const paymentSelect = document.getElementById('payment');

let cart = [];

// Initialize product buttons
prodBtns.forEach(btn => {
  btn.addEventListener('click', ()=>{
    prodBtns.forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    currentProd = btn.dataset.prod;
    renderPreview();
  });
});

// Render initial preview area with simple SVG mockup based on product
function renderPreview(imageSrc) {
  let html = '';
  if(currentProd === 'mug') {
    html = `<svg width="300" height="220" viewBox="0 0 300 220" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="10" rx="12" ry="12" width="220" height="180" fill="#ffffff" stroke="#ddd"/>
      <rect x="230" y="60" width="50" height="90" rx="20" fill="#ddd"/>
      ${ imageSrc ? `<image href="${imageSrc}" x="25" y="25" width="190" height="170" preserveAspectRatio="xMidYMid slice"/>` : `<text x="130" y="110" fill="#999" font-size="18" text-anchor="middle">معاينة الكوب</text>` }
      </svg>`;
  } else if(currentProd === 'tshirt') {
    html = `<svg width="300" height="320" viewBox="0 0 300 320" xmlns="http://www.w3.org/2000/svg">
      <rect x="30" y="40" width="240" height="220" rx="12" fill="#fff" stroke="#ddd"/>
      ${ imageSrc ? `<image href="${imageSrc}" x="60" y="80" width="180" height="140" preserveAspectRatio="xMidYMid slice"/>` : `<text x="150" y="150" fill="#999" font-size="18" text-anchor="middle">معاينة التيشيرت</text>` }
      </svg>`;
  } else if(currentProd === 'pillow') {
    html = `<svg width="300" height="240" viewBox="0 0 300 240" xmlns="http://www.w3.org/2000/svg">
      <rect x="20" y="20" width="260" height="200" rx="18" fill="#fff" stroke="#ddd"/>
      ${ imageSrc ? `<image href="${imageSrc}" x="40" y="40" width="220" height="160" preserveAspectRatio="xMidYMid slice"/>` : `<text x="150" y="120" fill="#999" font-size="18" text-anchor="middle">معاينة الوسادة</text>` }
      </svg>`;
  }
  previewWrapper.innerHTML = html;
}

// Handle image upload and preview
imgInput.addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = function(ev) {
    const src = ev.target.result;
    renderPreview(src);
    // store preview image on the previewWrapper for cart use
    previewWrapper.dataset.img = src;
  };
  reader.readAsDataURL(file);
});

// Live update text on preview (simple overlay simulation)
textInput.addEventListener('input', ()=>{
  // For simplicity, we'll show text below SVG as "mockup"
  let text = textInput.value.trim();
  let tEl = document.getElementById('mockupText');
  if(!tEl) {
    tEl = document.createElement('div');
    tEl.id = 'mockupText';
    tEl.style.marginTop = '8px';
    tEl.style.textAlign = 'center';
    previewWrapper.parentElement.appendChild(tEl);
  }
  tEl.textContent = text ? text : '';
});

// Add to cart
addToCartBtn.addEventListener('click', ()=>{
  const qty = parseInt(qtyInput.value) || 1;
  const img = previewWrapper.dataset.img || '';
  const text = textInput.value || '';
  const item = {product: currentProd, qty, img, text, id: Date.now()};
  cart.push(item);
  renderCart();
});

function renderCart() {
  if(cart.length === 0) {
    cartEmpty.style.display = 'block';
    cartList.style.display = 'none';
    orderForm.style.display = 'none';
    return;
  }
  cartEmpty.style.display = 'none';
  cartList.style.display = 'block';
  orderForm.style.display = 'block';
  cartList.innerHTML = '';
  cart.forEach(it => {
    const div = document.createElement('div');
    div.className = 'item';
    div.innerHTML = `<div><strong>${translateProd(it.product)}</strong> x ${it.qty}<div style="font-size:12px;color:#666">${it.text}</div></div>
    <div><button data-id="${it.id}" class="remove">حذف</button></div>`;
    cartList.appendChild(div);
  });
  // attach remove handlers
  document.querySelectorAll('.remove').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = parseInt(btn.dataset.id);
      cart = cart.filter(c=>c.id !== id);
      renderCart();
    });
  });
}

function translateProd(p){
  if(p==='mug') return 'كوب';
  if(p==='tshirt') return 'تيشيرت';
  if(p==='pillow') return 'وسادة';
  return p;
}

// Handle order submission (simulate)
orderForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  if(cart.length === 0) {
    orderMsg.textContent = 'السلة فارغة.';
    return;
  }
  const data = {
    name: document.getElementById('name').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    address: document.getElementById('address').value.trim(),
    payment: paymentSelect.value,
    cart
  };
  // In a real app, here you'd send data to a server. We'll simulate success:
  console.log('Order data', data);
  orderMsg.style.color = 'green';
  orderMsg.textContent = 'تم إرسال الطلب! سنتواصل معك لتأكيد الدفع والتوصيل.';
  // reset
  cart = [];
  renderCart();
  orderForm.reset();
});

// initial render
renderPreview();
